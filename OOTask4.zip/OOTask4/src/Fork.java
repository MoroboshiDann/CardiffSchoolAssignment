public class Fork {
    public boolean inUse = false;
}
