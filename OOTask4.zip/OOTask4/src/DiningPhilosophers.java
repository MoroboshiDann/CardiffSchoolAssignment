public class DiningPhilosophers {
    public static void main(String[] args) throws Exception {
        final int problemSize = 5;
        Fork leftFork;
        Fork rightFork;

        Philosopher[] philosophers = new Philosopher[problemSize];
        Fork[] forks = new Fork[problemSize];

        for (int i = 0; i < problemSize; i++) {
            forks[i] = new Fork();
        }
        int i = 0;
        for (; i < problemSize - 1; i++) {
            leftFork = forks[i];
            rightFork = forks[(i + 1) % problemSize];

            philosophers[i] = new Philosopher(leftFork, rightFork, i + 1);

            Thread t = new Thread(philosophers[i]);
            t.start();
        }
        // let the last philosopher pick up the one on the right first
        leftFork =  forks[(i + 1) % problemSize];
        rightFork =  forks[i];
        philosophers[i] = new Philosopher(leftFork, rightFork, i + 1);
        Thread t = new Thread(philosophers[i]);
        t.start();
    }
}
