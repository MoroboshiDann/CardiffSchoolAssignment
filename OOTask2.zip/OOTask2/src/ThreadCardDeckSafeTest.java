public class ThreadCardDeckSafeTest extends ThreadSafeCardDeck implements Runnable {
    @Override
    public void run() {
        while (cardList.size() > 0) {
            System.out.println(dealCard());
        }
        System.out.println(sequenceNumber);
    }

    public static void main(String[] args) {
        ThreadCardDeckSafeTest cdtst = new ThreadCardDeckSafeTest();
        Thread th1 = new Thread(cdtst);
        Thread th2 = new Thread(cdtst);

        th1.start();
        th2.start();
    }
}
