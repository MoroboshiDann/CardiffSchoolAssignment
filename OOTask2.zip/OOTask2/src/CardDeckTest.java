public class CardDeckTest extends CardDeck implements Runnable {
    @Override
    public void run() {
        for (int i = 0; i < 52; i++) {
            System.out.println(dealCard());
        }
        System.out.println(sequenceNumber);
    }

    public static void main(String[] args) {
        CardDeckTest cdt = new CardDeckTest();
        Thread th1 = new Thread(cdt);
        Thread th2 = new Thread(cdt);

        th1.start();
        th2.start();
    }
}
