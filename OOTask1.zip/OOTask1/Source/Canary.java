public class Canary extends Bird {
  @Override
  public String classOfAnimal() { return("Canary"); }
  @Override
  public boolean canFly() { return true; }
}
