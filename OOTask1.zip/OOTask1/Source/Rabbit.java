public class Rabbit extends SmallMammal {
  @Override
  public String classOfAnimal() { return("Rabbit"); }
  @Override
  public boolean canFly() { return false; }
}
