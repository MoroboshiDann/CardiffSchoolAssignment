public class ZebraFinch extends Bird {
  @Override
  public String classOfAnimal() { return("ZebraFinch"); } 
  @Override
  public boolean canFly() { return true; }
}
