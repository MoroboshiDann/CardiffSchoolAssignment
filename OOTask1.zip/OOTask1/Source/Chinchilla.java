public class Chinchilla extends SmallMammal { 
  @Override
  public String classOfAnimal() { return("Chinchilla"); } 
  @Override
  public boolean canFly() { return false; }
}
