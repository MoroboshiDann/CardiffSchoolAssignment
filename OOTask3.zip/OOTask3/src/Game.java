import java.util.Scanner;

public class Game {
    public static void main(String[] args) throws Exception {
        CardGame cardGame = new CardGame();
        DieGame dieGame = new DieGame();
        Scanner sc = new Scanner(System.in);
        System.out.println("Card (c) or Die (d) game? ");
        String ans = sc.nextLine();
        switch (ans) {
            case "c" -> cardGame.playCardGame();
            case "d" -> dieGame.playDieGame();
            default -> System.out.println("Input not understood");
        }
    }
}
