import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class CardGame {
    // The random number generator used
    private RandomInterface r;
    // The BufferedReader used
    private BufferedReader br;
    private ThreadSafeCardDeck d;
    private ArrayList<String> cardsChosen;

    public CardGame() {
        r = new LinearCongruentialGenerator();
        br = new BufferedReader(new InputStreamReader(System.in));
        cardsChosen = new ArrayList<String>();
    }

    public void playCardGame() throws Exception {
        // Play card game:

        // Initialise the game
        initialiseCardGame();

        // Play the main game phase
        mainCardGame();

        // Now see if (s)he has won!
        declareCardGameWinner();
    }

    private void initialiseCardGame() throws Exception {
        this.d = new ThreadSafeCardDeck();
    }

    private void mainCardGame() throws Exception {
        for (int i = 0; i < 2; i++) {
            System.out.println("Hit <RETURN> to choose a card");
            br.readLine();
            String choice = this.d.dealCard();
            System.out.println("You chose " + choice);
            cardsChosen.add(choice);
        }

        // Display the cards chosen and remaining cards
        System.out.println("Cards chosen: " + cardsChosen);
        System.out.println("Remaining cards: " + d.cardList);

    }

    private void declareCardGameWinner() throws Exception {
        // Declare the winner:

        // User wins if one of them is an Ace
        System.out.println("Cards chosen: " + cardsChosen);
        if (cardsChosen.contains("AHrts") || cardsChosen.contains("ADmnds") ||
                cardsChosen.contains("ASpds") || cardsChosen.contains("AClbs")) {
            System.out.println("You won!");
        } else System.out.println("You lost!");
    }

    public static void main(String[] args) throws Exception {
        System.out.println("Playing card game");
        CardGame cardGame = new CardGame();
        cardGame.playCardGame();
    }

}
